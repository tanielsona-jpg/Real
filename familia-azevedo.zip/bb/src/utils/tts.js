const ELEVENLABS_KEY = process.env.REACT_APP_ELEVENLABS_KEY;
const VOICE_ID       = 'JBFqnCBsd6RMkjVDRZzb'; // George — masculino, caloroso, pt-BR

const cache = new Map();

// Endpoint de streaming — começa a tocar assim que os primeiros bytes chegam
export async function playTTSStream(text, audioRef, onStop) {
  if (!ELEVENLABS_KEY) { console.error('[TTS] chave não encontrada'); return; }

  // Reusa blob do cache se disponível
  if (cache.has(text)) {
    const url   = URL.createObjectURL(cache.get(text));
    const audio = new Audio(url);
    audioRef.current = audio;
    audio.onended = () => { URL.revokeObjectURL(url); audioRef.current = null; onStop?.(); };
    audio.onerror = () => { URL.revokeObjectURL(url); audioRef.current = null; };
    return audio.play().catch(err => console.error('[TTS] play error:', err));
  }

  const res = await fetch(
    `https://api.elevenlabs.io/v1/text-to-speech/${VOICE_ID}/stream`,
    {
      method:  'POST',
      headers: { 'xi-api-key': ELEVENLABS_KEY, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        text,
        model_id:       'eleven_multilingual_v2',
        language_code:  'pt-BR',
        voice_settings: { stability: 0.5, similarity_boost: 0.75 },
      }),
    }
  );

  if (!res.ok) {
    const msg = await res.text().catch(() => res.status);
    throw new Error(`ElevenLabs ${res.status}: ${msg}`);
  }

  // Lê o stream completo e armazena em cache
  const blob = await res.blob();
  cache.set(text, blob);

  const url   = URL.createObjectURL(blob);
  const audio = new Audio(url);
  audioRef.current = audio;
  audio.onended = () => { URL.revokeObjectURL(url); audioRef.current = null; onStop?.(); };
  audio.onerror = (e) => { console.error('[TTS] audio error', e); URL.revokeObjectURL(url); };
  return audio.play().catch(err => console.error('[TTS] play error:', err));
}

// Chame durante um gesto do usuário para desbloquear autoplay no browser
export function unlockAudio() {
  const a = new Audio();
  a.play().catch(() => {});
}
