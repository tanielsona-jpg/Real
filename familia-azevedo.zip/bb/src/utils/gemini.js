import { getCached, setCached } from './aiCache';

const API_KEY = process.env.REACT_APP_GROQ_API_KEY;
const BASE    = 'https://api.groq.com/openai/v1/chat/completions';
const MODEL   = 'llama-3.1-8b-instant';

const MOCK_MODE = false;

const RESPOSTAS_MOCK = [
  "Deus está cuidando de você mesmo no silêncio. Confie n'Ele com todo o seu coração! 🙏",
  "A Palavra de Deus é viva e eficaz. Este capítulo tem muito a nos ensinar sobre a fidelidade d'Ele.",
  "Que passagem poderosa! Lembre-se: 'Tudo posso naquele que me fortalece.' — Filipenses 4:13 ❤️‍🔥",
  "O Senhor é o seu pastor, nada lhe faltará. Descanse nas promessas d'Ele hoje!",
  "Este texto nos lembra que o amor de Deus é incondicional e eterno. Que bênção!",
  "Deus nunca abandona os seus. Continue firme na fé! 🕊️",
];

const SYSTEM_PROMPT = `Você é a Canela de Fogo, uma assistente bíblica cristã gentil, sábia e acolhedora.
Responda sempre com base nas Escrituras Sagradas, com linguagem simples e edificante.
Use contexto cristão evangélico. Cite versículos quando relevante.
Seja breve, calorosa e encorajadora. Nunca saia do contexto bíblico ou cristão.
Nunca revele que é uma IA ou mencione o Groq, Llama ou qualquer modelo. Você é a Canela de Fogo.`;

// ─── Utilitário interno de chamada ───────────────────────────────
async function callGroq(messages, maxTokens = 512) {
  const res = await fetch(BASE, {
    method:  'POST',
    headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${API_KEY}` },
    body: JSON.stringify({ model: MODEL, messages, temperature: 0.7, max_tokens: maxTokens }),
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    console.error('[Groq] Erro HTTP', res.status, err);
    throw new Error(err?.error?.message || `Erro ${res.status}`);
  }
  const data = await res.json();
  const text = data?.choices?.[0]?.message?.content;
  if (!text) throw new Error('Resposta vazia da IA.');
  return text.trim();
}

// ─── Chat da Canela de Fogo ──────────────────────────────────────
export async function perguntarCanela({ pergunta, livro, capitulo, textoCapitulo, historico = [] }) {
  if (MOCK_MODE) {
    await new Promise(r => setTimeout(r, 800));
    return RESPOSTAS_MOCK[Math.floor(Math.random() * RESPOSTAS_MOCK.length)];
  }
  const contexto = livro && capitulo
    ? `Contexto: o usuário está lendo ${livro} capítulo ${capitulo}.\n\nTexto do capítulo:\n${textoCapitulo}\n\n`
    : '';
  const messages = [
    { role: 'system', content: SYSTEM_PROMPT },
    ...historico.map(m => ({ role: m.de === 'user' ? 'user' : 'assistant', content: m.texto })),
    { role: 'user', content: `${contexto}${pergunta}` },
  ];
  try {
    return await callGroq(messages, 512);
  } catch (err) {
    console.error('[Groq] Erro completo:', err);
    throw err;
  }
}

// ─── Resumo + perguntas de reflexão (uma só chamada) ────────────
export async function gerarInsights({ livro, capitulo, texto }) {
  const key    = `insights_${livro}_${capitulo}`;
  const cached = getCached(key);
  if (cached) return cached;

  const messages = [
    { role: 'system', content: SYSTEM_PROMPT },
    {
      role: 'user',
      content:
        `Analise ${livro} capítulo ${capitulo}.\n\nTexto:\n${texto.slice(0, 3000)}\n\n` +
        `Responda SOMENTE com este JSON (sem texto fora dele):\n` +
        `{"resumo":"2 frases resumindo o capítulo","perguntas":["pergunta reflexiva 1","pergunta reflexiva 2","pergunta reflexiva 3"]}`,
    },
  ];

  try {
    const raw    = await callGroq(messages, 600);
    const jsonStr = raw.match(/\{[\s\S]*\}/)?.[0] ?? raw;
    const result  = JSON.parse(jsonStr);
    if (!result.resumo || !Array.isArray(result.perguntas)) throw new Error('formato inválido');
    setCached(key, result);
    return result;
  } catch (err) {
    console.error('[Groq] gerarInsights erro:', err);
    throw new Error('Não foi possível gerar os insights deste capítulo.');
  }
}

// ─── Explicação de palavra difícil ───────────────────────────────
export async function explicarPalavra({ palavra, livro, capitulo, versiculo }) {
  const key    = `palavra_${palavra.toLowerCase()}_${livro}_${capitulo}`;
  const cached = getCached(key);
  if (cached) return cached;

  const messages = [
    { role: 'system', content: SYSTEM_PROMPT },
    {
      role: 'user',
      content:
        `Em ${livro} ${capitulo}:${versiculo}, explique a palavra "${palavra}" em 2-3 frases simples. ` +
        `Inclua o significado histórico/bíblico original e como se aplica à vida cristã hoje.`,
    },
  ];

  try {
    const result = await callGroq(messages, 250);
    setCached(key, result);
    return result;
  } catch (err) {
    console.error('[Groq] explicarPalavra erro:', err);
    throw new Error('Não foi possível explicar esta palavra.');
  }
}

// ─── Plano de leitura personalizado ─────────────────────────────
export async function gerarPlanoLeitura({ livro, totalCaps, lidos, capsPorDia }) {
  const restantes = totalCaps - lidos;
  const messages  = [
    { role: 'system', content: SYSTEM_PROMPT },
    {
      role: 'user',
      content:
        `Crie um plano de leitura para o livro de ${livro} (${totalCaps} capítulos no total). ` +
        `Já foram lidos ${lidos} capítulos; restam ${restantes}. ` +
        `Ritmo: ${capsPorDia} capítulo(s) por dia. ` +
        `Organize por semanas, seja motivador e inclua uma dica espiritual para cada semana. ` +
        `Use formato simples com emojis.`,
    },
  ];
  try {
    return await callGroq(messages, 700);
  } catch (err) {
    console.error('[Groq] gerarPlanoLeitura erro:', err);
    throw new Error('Não foi possível gerar o plano de leitura.');
  }
}

// ─── Paráfrase de capítulo inteiro (fallback para NVT / NVI) ─────
const ESTILO_DESC = {
  NVT: 'Nova Versão Transformadora (NVT): linguagem contemporânea, fluida e natural do português brasileiro atual, sem arcaísmos',
  NVI: 'Nova Versão Internacional (NVI): linguagem clara, precisa e acessível, fiel ao sentido original, sem palavras difíceis',
};

export async function gerarParafraseCapitulo({ versosARA, livro, capitulo, estilo }) {
  const key    = `parafrase_${estilo}_${livro}_${capitulo}`;
  const cached = getCached(key);
  if (cached) return cached;

  const estiloDesc  = ESTILO_DESC[estilo] ?? estilo;
  const versosTexto = versosARA.map(v => `[${v.verse}] ${v.text}`).join('\n');

  const messages = [
    {
      role: 'system',
      content:
        'Você é um especialista em tradução bíblica para o português brasileiro. ' +
        'Responda SOMENTE com JSON válido, sem nenhum texto fora do JSON.',
    },
    {
      role: 'user',
      content:
        `Parafraseie cada versículo de ${livro} capítulo ${capitulo} no estilo da ${estiloDesc}.\n\n` +
        `Texto base (ARA):\n${versosTexto}\n\n` +
        `Retorne EXATAMENTE este JSON (um objeto por versículo, mesma ordem e mesma numeração):\n` +
        `[{"v":1,"t":"..."},{"v":2,"t":"..."},...]`,
    },
  ];

  try {
    const raw     = await callGroq(messages, 3500);
    const jsonStr = raw.match(/\[[\s\S]*\]/)?.[0] ?? raw;
    const parsed  = JSON.parse(jsonStr);
    if (!Array.isArray(parsed) || parsed.length === 0) throw new Error('formato inválido');
    const result  = parsed.map(item => ({ verse: Number(item.v), text: String(item.t) }));
    setCached(key, result, 30);
    return result;
  } catch (err) {
    console.error('[Groq] gerarParafraseCapitulo erro:', err);
    throw new Error(`Não foi possível gerar a paráfrase ${estilo}.`);
  }
}
