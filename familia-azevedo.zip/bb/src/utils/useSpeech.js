import { useState, useRef, useCallback, useEffect } from 'react';
import { playTTSStream } from './tts';

export function useSpeech() {
  const [activeVerse, setActiveVerse] = useState(null);
  const [isPlaying,   setIsPlaying]   = useState(false);
  const [isPaused,    setIsPaused]    = useState(false);

  const audioRef   = useRef(null);
  const stoppedRef = useRef(true);
  const versesRef  = useRef([]);
  const indexRef   = useRef(0);
  const speakRef   = useRef(null);

  const doStop = useCallback(() => {
    stoppedRef.current = true;
    const a = audioRef.current;
    audioRef.current = null;
    if (a) { a.pause(); a.src = ''; }
    setIsPlaying(false);
    setIsPaused(false);
    setActiveVerse(null);
  }, []);

  async function utterVerse(text, verseNum, onEnd) {
    if (stoppedRef.current) return;
    try {
      setActiveVerse(verseNum);
      await playTTSStream(text, audioRef, () => {
        if (!stoppedRef.current) onEnd();
      });
    } catch (err) {
      console.error('[TTS] utterVerse error:', err);
      if (!stoppedRef.current) onEnd();
    }
  }

  speakRef.current = function speakNext() {
    if (stoppedRef.current) return;
    const verses = versesRef.current;
    const idx    = indexRef.current;
    if (idx >= verses.length) { doStop(); return; }
    const v = verses[idx];
    utterVerse(v.text, v.verse, () => {
      indexRef.current++;
      speakRef.current?.();
    });
  };

  const playVerse = useCallback((text, verseNum) => {
    doStop();
    stoppedRef.current = false;
    setIsPlaying(true);
    setIsPaused(false);
    utterVerse(text, verseNum, () => doStop());
  }, [doStop]); // eslint-disable-line react-hooks/exhaustive-deps

  const playChapter = useCallback((verses) => {
    doStop();
    stoppedRef.current = false;
    versesRef.current  = verses;
    indexRef.current   = 0;
    setIsPlaying(true);
    setIsPaused(false);
    speakRef.current?.();
  }, [doStop]);

  const pause  = useCallback(() => { audioRef.current?.pause(); setIsPaused(true);  }, []);
  const resume = useCallback(() => { audioRef.current?.play();  setIsPaused(false); }, []);

  useEffect(() => doStop, [doStop]);

  return { activeVerse, isPlaying, isPaused, playVerse, playChapter, pause, resume, stop: doStop };
}
