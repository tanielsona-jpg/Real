const PRE = 'fa_ai_';

export function getCached(key) {
  try {
    const raw = localStorage.getItem(PRE + key);
    if (!raw) return null;
    const { v, exp } = JSON.parse(raw);
    if (exp && Date.now() > exp) { localStorage.removeItem(PRE + key); return null; }
    return v;
  } catch { return null; }
}

export function setCached(key, value, ttlDays = 60) {
  try {
    localStorage.setItem(PRE + key, JSON.stringify({
      v:   value,
      exp: ttlDays ? Date.now() + ttlDays * 86400000 : null,
    }));
  } catch {}
}
