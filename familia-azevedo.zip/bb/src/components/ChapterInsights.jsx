import { useState, useEffect } from "react";
import { gerarInsights } from "../utils/gemini";

// ─────────────────────────────────────────────────────────────────
// ChapterInsights — resumo colapsável + 3 perguntas de reflexão
// ─────────────────────────────────────────────────────────────────
export default function ChapterInsights({ livro, capitulo, texto }) {
  const [open, setOpen]         = useState(false);
  const [tab, setTab]           = useState("resumo"); // 'resumo' | 'perguntas'
  const [insights, setInsights] = useState(null);
  const [loading, setLoading]   = useState(false);
  const [error, setError]       = useState("");

  // Carrega quando o card é aberto pela primeira vez
  useEffect(() => {
    if (!open || insights || loading) return;
    if (!texto) return;

    setLoading(true);
    setError("");
    gerarInsights({ livro, capitulo, texto })
      .then(setInsights)
      .catch(e => setError(e.message))
      .finally(() => setLoading(false));
  }, [open, livro, capitulo, texto]); // eslint-disable-line react-hooks/exhaustive-deps

  // Reseta quando muda de capítulo
  useEffect(() => {
    setOpen(false);
    setInsights(null);
    setError("");
    setTab("resumo");
  }, [livro, capitulo]);

  return (
    <div className="insights-card">
      <button className="insights-toggle" onClick={() => setOpen(o => !o)}>
        <span className="insights-toggle__icon">✦</span>
        <span className="insights-toggle__label">Além da Letra</span>
        <span className="insights-toggle__arrow">{open ? "▲" : "▼"}</span>
      </button>

      {open && (
        <div className="insights-body">
          <div className="insights-tabs">
            <button
              className={`insights-tab${tab === "resumo" ? " insights-tab--active" : ""}`}
              onClick={() => setTab("resumo")}
            >
              📋 Resumo
            </button>
            <button
              className={`insights-tab${tab === "perguntas" ? " insights-tab--active" : ""}`}
              onClick={() => setTab("perguntas")}
            >
              💭 Reflexão
            </button>
          </div>

          {loading && (
            <div className="insights-loading">
              <span /><span /><span />
            </div>
          )}

          {!loading && error && (
            <p className="insights-error">⚠ {error}</p>
          )}

          {!loading && insights && tab === "resumo" && (
            <p className="insights-resumo">{insights.resumo}</p>
          )}

          {!loading && insights && tab === "perguntas" && (
            <ol className="insights-questions">
              {insights.perguntas.map((q, i) => (
                <li key={i} className="insights-question">{q}</li>
              ))}
            </ol>
          )}
        </div>
      )}
    </div>
  );
}
