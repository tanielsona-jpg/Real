import { useState } from "react";
import { gerarPlanoLeitura } from "../utils/gemini";

// ─────────────────────────────────────────────────────────────────
// ReadingPlan — plano de leitura personalizado
// ─────────────────────────────────────────────────────────────────
export default function ReadingPlan({ studyBook, readChapters, chaptersByBook }) {
  const totalCaps = chaptersByBook[studyBook] || 1;
  const lidos     = new Set(
    (readChapters || [])
      .filter(k => k.startsWith(studyBook + "||"))
      .map(k => k.split("||")[1])
  ).size;
  const restantes  = Math.max(0, totalCaps - lidos);
  const pct        = Math.round((lidos / totalCaps) * 100);

  const [capsPorDia, setCapsPorDia] = useState(1);
  const [plano, setPlano]           = useState("");
  const [loading, setLoading]       = useState(false);
  const [error, setError]           = useState("");
  const [open, setOpen]             = useState(false);

  async function handleGerar() {
    setLoading(true); setError(""); setPlano("");
    try {
      const result = await gerarPlanoLeitura({ livro: studyBook, totalCaps, lidos, capsPorDia });
      setPlano(result);
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="card">
      <button className="insights-toggle" onClick={() => setOpen(o => !o)}>
        <span className="insights-toggle__icon">📅</span>
        <span className="insights-toggle__label">Plano de leitura</span>
        <span className="insights-toggle__arrow">{open ? "▲" : "▼"}</span>
      </button>

      {open && (
        <div style={{ paddingTop: 14 }}>
          {/* Progresso atual */}
          <div className="plan-progress-row">
            <span className="plan-book">{studyBook}</span>
            <span className="plan-stats">{lidos}/{totalCaps} caps — {pct}%</span>
          </div>
          <div className="you-progress-bar" style={{ marginBottom: 16 }}>
            <div className="you-progress-bar__fill you-progress-bar__fill--green" style={{ width: `${pct}%` }} />
          </div>

          {restantes > 0 ? (
            <>
              <div className="plan-input-row">
                <label className="plan-label">Capítulos por dia:</label>
                <div className="plan-stepper">
                  <button onClick={() => setCapsPorDia(c => Math.max(1, c - 1))}>−</button>
                  <span>{capsPorDia}</span>
                  <button onClick={() => setCapsPorDia(c => Math.min(10, c + 1))}>+</button>
                </div>
                <span className="plan-estimate">
                  ≈ {Math.ceil(restantes / capsPorDia)} dias
                </span>
              </div>

              <button
                className="btn btn--primary btn--full"
                onClick={handleGerar}
                disabled={loading}
                style={{ marginTop: 8 }}
              >
                {loading ? "Gerando plano..." : "Gerar plano com IA"}
              </button>

              {error && <p className="insights-error" style={{ marginTop: 8 }}>⚠ {error}</p>}

              {plano && (
                <div className="plan-result">
                  {plano.split("\n").map((line, i) => (
                    <p key={i} className={line.startsWith("**") || line.startsWith("##") ? "plan-week-title" : "plan-line"}>
                      {line.replace(/\*\*/g, "").replace(/^##\s*/, "")}
                    </p>
                  ))}
                </div>
              )}
            </>
          ) : (
            <p className="plan-done">🎉 Você concluiu {studyBook}! Que conquista!</p>
          )}
        </div>
      )}
    </div>
  );
}
