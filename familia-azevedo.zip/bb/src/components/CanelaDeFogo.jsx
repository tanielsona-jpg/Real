import { useEffect, useRef, useState } from "react";
import { perguntarCanela } from "../utils/gemini";

export default function CanelaDeFogo({ livro, capitulo, textoCapitulo }) {
  const [aberto, setAberto]         = useState(false);
  const [pergunta, setPergunta]     = useState("");
  const [historico, setHistorico]   = useState([]);
  const [carregando, setCarregando] = useState(false);
  const messagesEndRef = useRef(null);

  useEffect(() => {
    if (aberto) messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [historico, aberto]);

  useEffect(() => {
    setHistorico([]);
  }, [livro, capitulo]);

  async function enviar() {
    const p = pergunta.trim();
    if (!p || carregando) return;

    const novoHistorico = [...historico, { de: "user", texto: p }];
    setPergunta("");
    setHistorico(novoHistorico);
    setCarregando(true);

    try {
      const resposta = await perguntarCanela({
        pergunta: p,
        livro,
        capitulo,
        textoCapitulo,
        historico,
      });
      setHistorico(h => [...h, { de: "canela", texto: resposta }]);
    } catch (err) {
      console.error("[CanelaDeFogo] Erro na API:", err);
      setHistorico(h => [...h, {
        de: "canela",
        texto: "Ops, não consegui responder agora. Tente novamente! 🙏",
        erro: true,
      }]);
    } finally {
      setCarregando(false);
    }
  }

  return (
    <div className="canela-wrapper">

      {aberto && (
        <div className="canela-panel">

          <div className="canela-panel__header">
            <div className="canela-panel__title">
              <span className="canela-panel__icon">❤️‍🔥</span>
              <span>Canela de Fogo</span>
            </div>
            <div className="canela-panel__context">
              {livro} {capitulo}
            </div>
          </div>

          <div className="canela-panel__messages">
            {historico.length === 0 && (
              <div className="canela-msg canela-msg--canela canela-msg--intro">
                Olá! Pode me perguntar qualquer coisa sobre{" "}
                <strong>{livro} {capitulo}</strong>. Estou aqui para
                ajudar na sua leitura 🕊️
              </div>
            )}

            {historico.map((msg, i) => (
              <div
                key={i}
                className={`canela-msg canela-msg--${msg.de}${msg.erro ? " canela-msg--erro" : ""}`}
              >
                {msg.texto}
              </div>
            ))}

            {carregando && (
              <div className="canela-msg canela-msg--canela canela-loading">
                <span />
                <span />
                <span />
              </div>
            )}

            <div ref={messagesEndRef} />
          </div>

          <div className="canela-panel__input">
            <input
              value={pergunta}
              onChange={e => setPergunta(e.target.value)}
              onKeyDown={e => e.key === "Enter" && !e.shiftKey && enviar()}
              placeholder="Pergunte sobre este capítulo..."
              disabled={carregando}
            />
            <button
              onClick={enviar}
              disabled={carregando || !pergunta.trim()}
              aria-label="Enviar"
            >
              →
            </button>
          </div>
        </div>
      )}

      <button
        className={`canela-fab${aberto ? " canela-fab--open" : ""}${carregando ? " canela-fab--thinking" : ""}`}
        onClick={() => setAberto(o => !o)}
        aria-label={aberto ? "Fechar Canela de Fogo" : "Abrir Canela de Fogo"}
      >
        {aberto ? "✕" : ""}
      </button>
    </div>
  );
}
