import { useState, useRef, useCallback, useEffect } from "react";
import { explicarPalavra } from "../utils/gemini";
import { playTTSStream, unlockAudio } from "../utils/tts";

const LONG_PRESS_MS = 600;
const MIN_WORD_LEN  = 4;

function tokenize(text) {
  return text.split(/(\s+)/).flatMap(chunk => {
    if (/^\s+$/.test(chunk)) return [{ t: chunk, word: null }];
    const m = chunk.match(/^([^a-zA-ZÀ-ú]*)([a-zA-ZÀ-ú]+(?:['-][a-zA-ZÀ-ú]+)*)([^a-zA-ZÀ-ú]*)$/);
    if (!m) return [{ t: chunk, word: null }];
    const [, pre, word, pos] = m;
    const result = [];
    if (pre)  result.push({ t: pre,  word: null });
    result.push({ t: word, word: word.length >= MIN_WORD_LEN ? word : null });
    if (pos)  result.push({ t: pos,  word: null });
    return result;
  });
}

export function VerseText({ text, livro, capitulo, versiculo }) {
  const [modal, setModal] = useState(null);
  const timerRef          = useRef(null);
  const audioRef          = useRef(null);

  function stopAudio() {
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current.src = '';
      audioRef.current = null;
    }
  }

  // Para ao fechar o modal
  useEffect(() => {
    if (modal === null) stopAudio();
  }, [modal]);

  // Reproduz quando a explicação chega
  useEffect(() => {
    const texto = modal?.texto;
    if (!texto) return;
    let cancelled = false;

    playTTSStream(texto, audioRef)
      .catch(err => console.error('[TTS] falha ao reproduzir explicação:', err));

    return () => { cancelled = true; };
  }, [modal?.texto]);

  const startPress = useCallback((word) => {
    if (!word) return;
    unlockAudio(); // desbloqueia autoplay durante o gesto
    timerRef.current = setTimeout(() => {
      setModal({ palavra: word, texto: null, loading: true, error: "" });

      explicarPalavra({ palavra: word, livro, capitulo, versiculo })
        .then(texto => setModal(m => m?.palavra === word ? { ...m, texto, loading: false } : m))
        .catch(e    => setModal(m => m?.palavra === word ? { ...m, error: e.message, loading: false } : m));
    }, LONG_PRESS_MS);
  }, [livro, capitulo, versiculo]);

  const cancelPress = useCallback(() => clearTimeout(timerRef.current), []);

  const tokens = tokenize(text);

  return (
    <>
      <p className="verse-text">
        {tokens.map((tok, i) =>
          tok.word ? (
            <span
              key={i}
              className="verse-word"
              onMouseDown={() => startPress(tok.word)}
              onMouseUp={cancelPress}
              onMouseLeave={cancelPress}
              onTouchStart={e => { e.stopPropagation(); startPress(tok.word); }}
              onTouchEnd={cancelPress}
              onTouchMove={cancelPress}
            >
              {tok.t}
            </span>
          ) : (
            tok.t
          )
        )}
      </p>

      {modal && (
        <div className="word-modal-overlay" onClick={() => setModal(null)}>
          <div className="word-modal" onClick={e => e.stopPropagation()}>
            <div className="word-modal__header">
              <span className="word-modal__word">"{modal.palavra}"</span>
              <button className="word-modal__close" onClick={() => setModal(null)}>✕</button>
            </div>

            {modal.loading && (
              <div className="insights-loading" style={{ padding: "14px 0" }}>
                <span /><span /><span />
              </div>
            )}

            {!modal.loading && modal.error && (
              <p className="insights-error">⚠ {modal.error}</p>
            )}

            {!modal.loading && modal.texto && (
              <p className="word-modal__text">{modal.texto}</p>
            )}

            <p className="word-modal__hint">{livro} {capitulo}:{versiculo}</p>
          </div>
        </div>
      )}
    </>
  );
}
