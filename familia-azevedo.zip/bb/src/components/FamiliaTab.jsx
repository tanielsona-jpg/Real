import { useState } from "react";

export const AVATAR_COLORS = [
  '#8b1a2e', '#2d6b43', '#b8862a', '#1a4a90', '#7b3fa0', '#c05b1a',
];

// ─────────────────────────────────────────────────────────────────
// MemberAvatar
// ─────────────────────────────────────────────────────────────────
export function MemberAvatar({ member, size = 44, isActive = false }) {
  const base = {
    width: size, height: size,
    borderRadius: '50%',
    flexShrink: 0,
    display: 'flex', alignItems: 'center', justifyContent: 'center',
    fontSize: Math.round(size * 0.4),
    fontFamily: 'Cormorant Garamond, serif',
    fontWeight: 700,
    color: '#fff',
    background: member.color || '#8b1a2e',
    overflow: 'hidden',
    boxSizing: 'border-box',
    position: 'relative',
    border: isActive ? '2.5px solid #fff' : 'none',
    boxShadow: isActive
      ? `0 0 0 2.5px ${member.color || '#8b1a2e'}, 0 2px 8px rgba(0,0,0,.2)`
      : '0 1px 4px rgba(0,0,0,.15)',
  };
  return (
    <div style={base}>
      {member.name.charAt(0).toUpperCase()}
      {member.photoURL && (
        <img
          src={member.photoURL}
          alt={member.name}
          referrerPolicy="no-referrer"
          style={{
            position: 'absolute', inset: 0,
            width: '100%', height: '100%',
            objectFit: 'cover', borderRadius: '50%',
          }}
          onError={e => { e.currentTarget.style.display = 'none'; }}
        />
      )}
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────
// FamilySetup — tela de criar/entrar em família
// ─────────────────────────────────────────────────────────────────
function FamilySetup({ uid, onCreateFamily, onJoinFamily, onLogin }) {
  const [mode, setMode]       = useState(null); // 'join'
  const [code, setCode]       = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError]     = useState('');

  if (!uid) {
    return (
      <div className="fsetup-card">
        <div className="fsetup-icon">👪</div>
        <h3 className="fsetup-title">Família em tempo real</h3>
        <p className="fsetup-desc">
          Faça login com o Google para ver o progresso de todos os membros da família.
        </p>
        <button className="btn btn--google btn--full" onClick={onLogin}>
          <img src="https://www.gstatic.com/firebasejs/ui/2.0.0/images/auth/google.svg" alt="Google" width="18" height="18" />
          Entrar com Google
        </button>
      </div>
    );
  }

  async function handleCreate() {
    setLoading(true); setError('');
    try {
      await onCreateFamily();
    } catch (e) {
      console.error('[FamilySetup] Erro ao criar família:', e);
      setError(e.message || 'Erro desconhecido. Verifique o console.');
    } finally {
      setLoading(false);
    }
  }

  async function handleJoin() {
    if (!code.trim()) { setError('Digite o código da família.'); return; }
    setLoading(true); setError('');
    try {
      await onJoinFamily(code);
    } catch (e) {
      console.error('[FamilySetup] Erro ao entrar na família:', e);
      setError(e.message || 'Erro desconhecido. Verifique o console.');
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="fsetup-card">
      <div className="fsetup-icon">👪</div>
      <h3 className="fsetup-title">Conectar família</h3>
      <p className="fsetup-desc">
        Crie um grupo familiar e compartilhe o código com os outros membros.
      </p>

      {error && <p className="fsetup-error">⚠ {error}</p>}

      {!mode && (
        <div className="fsetup-btns">
          <button className="btn btn--primary btn--full" onClick={handleCreate} disabled={loading}>
            {loading ? 'Criando...' : 'Criar família'}
          </button>
          <button className="btn btn--ghost btn--full" onClick={() => setMode('join')} disabled={loading}>
            Entrar com código
          </button>
        </div>
      )}

      {mode === 'join' && (
        <div className="fsetup-form">
          <input
            className="fsetup-input"
            placeholder="Código da família (ex: AB3X7K)"
            value={code}
            onChange={e => { setCode(e.target.value.toUpperCase()); setError(''); }}
            onKeyDown={e => e.key === 'Enter' && handleJoin()}
            autoFocus
          />
          <button className="btn btn--primary btn--full" onClick={handleJoin} disabled={loading}>
            {loading ? 'Entrando...' : 'Entrar na família'}
          </button>
          <button className="btn btn--ghost btn--full" onClick={() => { setMode(null); setError(''); setCode(''); }}>
            Voltar
          </button>
        </div>
      )}
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────
// FamiliaTab — tela principal de família
// ─────────────────────────────────────────────────────────────────
export default function FamiliaTab({
  uid,
  user,
  familyId,
  familyDoc,
  members,
  studyBook,
  setStudyBook,
  lastStudyChapter,
  chaptersByBook,
  continueStudy,
  openBook,
  books,
  onCreateFamily,
  onJoinFamily,
  onLeaveFamily,
  onLogin,
}) {
  const [showStudyPicker, setShowStudyPicker] = useState(false);
  const [showCode, setShowCode]               = useState(false);
  const [confirmLeave, setConfirmLeave]       = useState(false);

  const totalChapters = chaptersByBook[studyBook] || 1;

  // Ainda sem família → mostra tela de setup
  if (!familyId || !familyDoc) {
    return (
      <div className="screen">
        <div className="screen-header">
          <h2 className="screen-title">Família</h2>
          <p className="screen-sub">Progresso da família em tempo real.</p>
        </div>
        <FamilySetup
          uid={uid}
          user={user}
          onCreateFamily={onCreateFamily}
          onJoinFamily={onJoinFamily}
          onLogin={onLogin}
        />
      </div>
    );
  }

  return (
    <div className="screen">
      <div className="screen-header">
        <h2 className="screen-title">Família</h2>
        <p className="screen-sub">{familyDoc.name || 'Família Azevedo'} · {members.length} {members.length === 1 ? 'membro' : 'membros'}</p>
      </div>

      {/* Código de convite */}
      <div className="fcode-bar">
        <span className="fcode-label">Código de convite:</span>
        {showCode
          ? <strong className="fcode-value">{familyId}</strong>
          : <button className="btn btn--ghost btn--sm" onClick={() => setShowCode(true)}>Ver código</button>
        }
        {showCode && (
          <button className="btn btn--ghost btn--sm" onClick={() => setShowCode(false)}>Ocultar</button>
        )}
      </div>

      {/* Livro de estudo compartilhado */}
      <div className="card card--study">
        <div className="card__eyebrow card__eyebrow--green">📖 Livro de estudo da família</div>

        <div className="you-study-row">
          <span className="you-study-name">{studyBook}</span>
          <button className="btn btn--ghost btn--sm" onClick={() => setShowStudyPicker(p => !p)}>
            {showStudyPicker ? '▲ Fechar' : '✎ Trocar'}
          </button>
        </div>

        {showStudyPicker && (
          <div className="you-book-picker">
            {books.map(b => (
              <button
                key={b}
                className={`you-book-picker__item${b === studyBook ? ' you-book-picker__item--active' : ''}`}
                onClick={() => { setStudyBook(b); setShowStudyPicker(false); }}
              >
                <span>{b}</span>
                {b === studyBook && <span className="you-book-picker__check">✓</span>}
              </button>
            ))}
          </div>
        )}

        {/* Comparativo visual */}
        <div className="familia-comparison">
          {members.map(member => {
            const chapter = member.studyChapters?.[studyBook] || 1;
            const pct     = Math.min(100, Math.round((chapter / totalChapters) * 100));
            const isOwn   = member.id === uid;
            return (
              <div key={member.id} className={`familia-cmp-row${isOwn ? ' familia-cmp-row--active' : ''}`}>
                <MemberAvatar member={member} size={26} isActive={isOwn} />
                <span className="familia-cmp-name">{member.name.split(' ')[0]}</span>
                <div className="familia-cmp-track">
                  <div className="familia-cmp-fill" style={{ width: `${Math.max(pct, 1)}%`, background: member.color }} />
                </div>
                <span className="familia-cmp-cap">cap.&nbsp;{chapter}</span>
                <span className="familia-cmp-pct">{pct}%</span>
              </div>
            );
          })}
        </div>

        <button className="btn btn--primary btn--full" onClick={continueStudy}>
          Continuar cap. {lastStudyChapter} →
        </button>
      </div>

      {/* Cards de cada membro */}
      <div className="familia-members-header">
        <span className="familia-section-label">MEMBROS</span>
      </div>

      <div className="familia-members-list">
        {members.map(member => {
          const isOwn      = member.id === uid;
          const allKeys    = member.readChapters || [];
          const totalRead  = allKeys.length;
          const allBooks   = allKeys.map(k => k.slice(0, k.lastIndexOf('||')));
          const booksOpen  = new Set(allBooks).size;
          const recentBooks = [...new Set([...allBooks].reverse())].slice(0, 3);
          const chapter    = member.studyChapters?.[studyBook] || 1;
          const pct        = Math.min(100, Math.round((chapter / totalChapters) * 100));

          return (
            <div
              key={member.id}
              className={`familia-card${isOwn ? ' familia-card--active' : ''}`}
              style={{ '--member-color': member.color }}
            >
              <div className="familia-card__header">
                <div className="familia-card__avatar-wrap">
                  <MemberAvatar member={member} size={50} isActive={isOwn} />
                </div>

                <div className="familia-card__identity">
                  <span className="familia-card__name">{member.name}</span>
                  <span className="familia-card__stats">
                    {totalRead} cap. · {booksOpen} {booksOpen === 1 ? 'livro' : 'livros'}
                  </span>
                </div>

                <div className="familia-card__actions">
                  {isOwn
                    ? <span className="familia-active-badge">Você</span>
                    : <span className="familia-online-dot" title="Online" />
                  }
                </div>
              </div>

              <div className="familia-card__progress">
                <div className="familia-card__progress-label">
                  <span>{studyBook}</span>
                  <span>cap. {chapter} / {totalChapters} — {pct}%</span>
                </div>
                <div className="you-progress-bar">
                  <div
                    className="you-progress-bar__fill"
                    style={{ width: `${Math.max(pct, 1)}%`, background: member.color }}
                  />
                </div>
              </div>

              {recentBooks.length > 0 && (
                <div className="familia-card__books">
                  {recentBooks.map(book => (
                    <button
                      key={book}
                      className="familia-book-chip"
                      style={{ '--chip-color': member.color }}
                      onClick={() => openBook(book)}
                    >
                      {book}
                    </button>
                  ))}
                  {booksOpen > 3 && (
                    <span className="familia-book-more">+{booksOpen - 3}</span>
                  )}
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Sair da família */}
      <div className="fleave-wrap">
        {confirmLeave ? (
          <div className="familia-confirm">
            <span>Sair da família?</span>
            <button className="familia-confirm__yes" onClick={() => { onLeaveFamily(); setConfirmLeave(false); }}>Sim</button>
            <button className="familia-confirm__no"  onClick={() => setConfirmLeave(false)}>Não</button>
          </div>
        ) : (
          <button className="btn btn--ghost btn--sm fleave-btn" onClick={() => setConfirmLeave(true)}>
            Sair da família
          </button>
        )}
      </div>
    </div>
  );
}
