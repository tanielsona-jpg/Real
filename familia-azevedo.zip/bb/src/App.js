import React, { useEffect, useMemo, useRef, useState } from "react";
import "./styles.css";
import {
  Home, BookOpen, Users, User,
  Moon, Sun,
  Play, Pause, Square,
  ChevronLeft, ChevronRight,
  Settings, Cloud, Globe, ChevronUp,
  Loader2, AlertTriangle, Sparkles, ArrowRight,
} from "lucide-react";
import ra from "./data/almeida_ra.json";
import rc from "./data/almeida_rc.json";

// Firebase
import { auth, db, googleProvider } from "./firebase";
import { onAuthStateChanged, signInWithRedirect, getRedirectResult, signOut } from "firebase/auth";
import { doc, getDoc, setDoc, onSnapshot, updateDoc, arrayUnion } from "firebase/firestore";

// Componentes
import Onboarding   from "./components/Onboarding";
import Anotacoes    from "./components/Anotacoes";
import CanelaDeFogo from "./components/CanelaDeFogo";
import FamiliaTab, { MemberAvatar, AVATAR_COLORS } from "./components/FamiliaTab";
import DevocionalCard   from "./components/DevocionalCard";
import ChapterInsights  from "./components/ChapterInsights";
import { VerseText }    from "./components/WordExplain";
import ReadingPlan      from "./components/ReadingPlan";
import { useSpeech }    from "./utils/useSpeech";

// API.Bible
import { fetchApiChapter } from "./utils/apiBible";
import { gerarParafraseCapitulo } from "./utils/gemini";

// ─────────────────────────────────────────────────────────────────

const THEME_KEY      = "fa_theme";
const TAB_KEY        = "fa_tab";
const ONBOARDING_KEY = "fa_onboarding_done";
const STUDY_BOOK_KEY = "fa_study_book";
const FAMILY_ID_KEY  = "fa_family_id";
const FONT_SIZE_KEY  = "fa_font_size";

const FONT_SIZES = { 1: 16, 2: 19, 3: 26 };
const FONT_LINES = { 1: 1.75, 2: 1.85, 3: 2.05 };

const VERSIONS = [
  { id: 'ARA', label: 'ARA', local: true  },
  { id: 'ARC', label: 'ARC', local: true  },
  { id: 'NVT', label: 'NVT', local: false },
  { id: 'NVI', label: 'NVI', local: false },
];

const TABS = [
  { id: "home",    Icon: Home,     label: "Início"  },
  { id: "bible",   Icon: BookOpen, label: "Bíblia"  },
  { id: "familia", Icon: Users,    label: "Família" },
  { id: "you",     Icon: User,     label: "Você"    },
];

const NT_BOOKS = new Set([
  "Mateus","Marcos","Lucas","João","Atos","Romanos",
  "1 Coríntios","2 Coríntios","Gálatas","Efésios","Filipenses","Colossenses",
  "1 Tessalonicenses","2 Tessalonicenses","1 Timóteo","2 Timóteo","Tito",
  "Filemom","Hebreus","Tiago","1 Pedro","2 Pedro",
  "1 João","2 João","3 João","Judas","Apocalipse",
]);

function generateCode() {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let code = "";
  for (let i = 0; i < 6; i++) code += chars[Math.floor(Math.random() * chars.length)];
  return code;
}

// ─────────────────────────────────────────────────────────────────
export default function App() {

  // ── Auth & onboarding ────────────────────────────────────────────
  const [user, setUser]             = useState(null);
  const [authReady, setAuthReady]   = useState(false);
  const [loginError, setLoginError] = useState("");
  const [onboardingDone, setOnboardingDone] = useState(
    !!localStorage.getItem(ONBOARDING_KEY)
  );

  // ── App state ────────────────────────────────────────────────────
  const [activeTab, setActiveTab] = useState(localStorage.getItem(TAB_KEY) || "home");
  const [theme, setTheme]         = useState(localStorage.getItem(THEME_KEY) || "light");
  const [fontSize, setFontSize]   = useState(() => Number(localStorage.getItem(FONT_SIZE_KEY)) || 2);
  const [selectedBook, setSelectedBook]       = useState(null);
  const [selectedChapter, setSelectedChapter] = useState(null);
  const [openOriginal, setOpenOriginal]       = useState({});
  const [originalText, setOriginalText]       = useState({});
  const [loadingOriginal, setLoadingOriginal] = useState({});

  // ── Versão da Bíblia ─────────────────────────────────────────────
  const [selectedVersion, setSelectedVersion] = useState("ARA");
  const [bibleTab, setBibleTab] = useState("vt"); // 'vt' | 'nt'
  const [apiVersesCache, setApiVersesCache]   = useState({});
  const [apiLoading, setApiLoading]           = useState(false);
  const [apiError, setApiError]               = useState(null);
  const [aiParaphraseKeys, setAiParaphraseKeys] = useState(() => new Set());

  // ── Progresso de leitura próprio ─────────────────────────────────
  const [readChapters, setReadChapters] = useState(() => {
    try { return JSON.parse(localStorage.getItem("fa_read") || "[]"); } catch { return []; }
  });
  const [studyChapters, setStudyChapters] = useState(() => {
    try { return JSON.parse(localStorage.getItem("fa_study_chapters") || "{}"); } catch { return {}; }
  });
  const [studyBook, setStudyBook] = useState(
    localStorage.getItem(STUDY_BOOK_KEY) || "Daniel"
  );

  // ── Família ──────────────────────────────────────────────────────
  const [familyId, setFamilyId]           = useState(localStorage.getItem(FAMILY_ID_KEY) || null);
  const [familyDoc, setFamilyDoc]         = useState(null);
  const [memberProfiles, setMemberProfiles] = useState({});

  // ── Leitura em voz alta ──────────────────────────────────────────
  const speech = useSpeech();

  const uid = user?.uid ?? null;
  const lastStudyChapter = studyChapters[studyBook] || 1;

  // ── Auth: detecta transição null → logado ────────────────────────
  const prevUserRef = useRef(undefined);

  useEffect(() => {
    getRedirectResult(auth).catch(err => {
      console.error('[Auth] redirect result error:', err);
    });

    const unsub = onAuthStateChanged(auth, (u) => {
      if (prevUserRef.current === null && u !== null) {
        setActiveTab("you");
        localStorage.setItem(TAB_KEY, "you");
      }
      prevUserRef.current = u;
      setUser(u);
      setAuthReady(true);
    });
    return unsub;
  }, []);

  // ── Carrega dados do usuário no login ────────────────────────────
  useEffect(() => {
    if (!uid) return;
    getDoc(doc(db, "users", uid)).then(snap => {
      if (!snap.exists()) return;
      const d = snap.data();
      // Sempre usa o familyId do Firestore como fonte de verdade
      if (d.familyId) {
        setFamilyId(d.familyId);
        localStorage.setItem(FAMILY_ID_KEY, d.familyId);
      } else {
        setFamilyId(null);
        localStorage.removeItem(FAMILY_ID_KEY);
      }
      // Usa dados remotos se tiver mais capítulos lidos
      if (Array.isArray(d.readChapters) && d.readChapters.length > readChapters.length) {
        setReadChapters(d.readChapters);
      }
      if (d.studyChapters && Object.keys(d.studyChapters).length > 0) {
        setStudyChapters(prev => ({ ...d.studyChapters, ...prev }));
      }
    }).catch(() => {});
  }, [uid]); // eslint-disable-line react-hooks/exhaustive-deps

  // ── Salva progresso próprio no Firestore (debounce 3s) ───────────
  useEffect(() => {
    if (!uid) return;
    const timer = setTimeout(() => {
      setDoc(doc(db, "users", uid), {
        name:          user?.displayName || localStorage.getItem("fa_nome") || "Membro",
        photoURL:      user?.photoURL || null,
        email:         user?.email || null,
        familyId:      familyId || null,
        readChapters,
        studyChapters,
      }, { merge: true }).catch(() => {});
    }, 3000);
    return () => clearTimeout(timer);
  }, [uid, readChapters, studyChapters, familyId, user]);

  // ── Listener em tempo real: documento da família ─────────────────
  useEffect(() => {
    if (!familyId) { setFamilyDoc(null); return; }
    const unsub = onSnapshot(doc(db, "families", familyId), snap => {
      if (!snap.exists()) return;
      const d = snap.data();
      setFamilyDoc(d);
      if (d.studyBook) setStudyBook(d.studyBook);
    });
    return unsub;
  }, [familyId]);

  // ── Listener em tempo real: perfis dos outros membros ───────────
  useEffect(() => {
    if (!familyDoc?.memberUids || !uid) return;
    const others = familyDoc.memberUids.filter(id => id !== uid);
    if (others.length === 0) return;

    const unsubbers = others.map(muid =>
      onSnapshot(doc(db, "users", muid), snap => {
        if (!snap.exists()) return;
        const d = snap.data();
        setMemberProfiles(prev => ({
          ...prev,
          [muid]: {
            id:           muid,
            name:         d.name || "Membro",
            photoURL:     d.photoURL || null,
            readChapters: d.readChapters || [],
            studyChapters: d.studyChapters || {},
          },
        }));
      })
    );
    return () => unsubbers.forEach(u => u());
  }, [familyDoc, uid]);

  // ── Persistência local ───────────────────────────────────────────
  useEffect(() => { localStorage.setItem(THEME_KEY, theme); }, [theme]);
  useEffect(() => { localStorage.setItem(TAB_KEY, activeTab); }, [activeTab]);
  useEffect(() => { localStorage.setItem(FONT_SIZE_KEY, fontSize); }, [fontSize]);
  useEffect(() => { localStorage.setItem(STUDY_BOOK_KEY, studyBook); }, [studyBook]);
  useEffect(() => { localStorage.setItem("fa_read", JSON.stringify(readChapters)); }, [readChapters]);
  useEffect(() => { localStorage.setItem("fa_study_chapters", JSON.stringify(studyChapters)); }, [studyChapters]);

  // ── Mudança de livro de estudo → atualiza família na nuvem ───────
  useEffect(() => {
    if (!familyId) return;
    setDoc(doc(db, "families", familyId), { studyBook }, { merge: true }).catch(() => {});
  }, [familyId, studyBook]);

  // ── Auto-scroll para versículo em leitura ───────────────────────
  useEffect(() => {
    if (!speech.activeVerse) return;
    document.getElementById(`verse-${speech.activeVerse}`)
      ?.scrollIntoView({ behavior: 'smooth', block: 'center' });
  }, [speech.activeVerse]);

  // Para a leitura ao mudar de capítulo
  useEffect(() => { speech.stop(); }, [selectedBook, selectedChapter]); // eslint-disable-line react-hooks/exhaustive-deps

  // ── Rastreia capítulos abertos ───────────────────────────────────
  useEffect(() => {
    if (!selectedBook || !selectedChapter) return;
    const key = `${selectedBook}||${selectedChapter}`;
    setReadChapters(prev => prev.includes(key) ? prev : [...prev, key]);
  }, [selectedBook, selectedChapter]);

  useEffect(() => {
    if (!selectedBook || !selectedChapter || selectedBook !== studyBook) return;
    setStudyChapters(prev => ({ ...prev, [studyBook]: Number(selectedChapter) }));
  }, [selectedBook, selectedChapter, studyBook]);

  // ── Ações de família ─────────────────────────────────────────────
  async function createFamily() {
    if (!uid) return;
    const code = generateCode();
    await setDoc(doc(db, "families", code), {
      name:       "Família Azevedo",
      studyBook,
      memberUids: [uid],
      createdBy:  uid,
    });
    await setDoc(doc(db, "users", uid), { familyId: code }, { merge: true });
    setFamilyId(code);
    localStorage.setItem(FAMILY_ID_KEY, code);
  }

  async function joinFamily(code) {
    if (!uid) return;
    const fid  = code.trim().toUpperCase();
    const snap = await getDoc(doc(db, "families", fid));
    if (!snap.exists()) throw new Error("Família não encontrada. Verifique o código.");
    await updateDoc(doc(db, "families", fid), { memberUids: arrayUnion(uid) });
    await setDoc(doc(db, "users", uid), { familyId: fid }, { merge: true });
    setFamilyId(fid);
    localStorage.setItem(FAMILY_ID_KEY, fid);
  }

  async function leaveFamily() {
    if (!uid || !familyId) return;
    await setDoc(doc(db, "users", uid), { familyId: null }, { merge: true });
    setFamilyId(null);
    setFamilyDoc(null);
    setMemberProfiles({});
    localStorage.removeItem(FAMILY_ID_KEY);
  }

  // ── Todos os membros (próprio + família em tempo real) ───────────
  const allMembers = useMemo(() => {
    const ownProfile = uid ? {
      id:           uid,
      name:         user?.displayName || localStorage.getItem("fa_nome") || "Você",
      photoURL:     user?.photoURL || null,
      readChapters,
      studyChapters,
    } : null;

    if (!familyDoc?.memberUids) {
      return ownProfile ? [{ ...ownProfile, color: AVATAR_COLORS[0] }] : [];
    }

    return familyDoc.memberUids.map((muid, idx) => {
      const color = AVATAR_COLORS[idx % AVATAR_COLORS.length];
      if (muid === uid) return ownProfile ? { ...ownProfile, color } : null;
      const p = memberProfiles[muid];
      return p ? { ...p, color } : null;
    }).filter(Boolean);
  }, [familyDoc, uid, user, readChapters, studyChapters, memberProfiles]);


  // ── Dados bíblicos ───────────────────────────────────────────────
  const books = useMemo(() => (
    [...new Set(ra.verses.map(v => v.book_name))]
  ), []);

  const chaptersByBook = useMemo(() => {
    const map = {};
    ra.verses.forEach(v => {
      if (!map[v.book_name]) map[v.book_name] = new Set();
      map[v.book_name].add(Number(v.chapter));
    });
    return Object.fromEntries(
      Object.entries(map).map(([k, v]) => [k, v.size])
    );
  }, []);

  const chapters = useMemo(() => {
    if (!selectedBook) return [];
    return [...new Set(
      ra.verses.filter(v => v.book_name === selectedBook).map(v => Number(v.chapter))
    )].sort((a, b) => a - b);
  }, [selectedBook]);

  const versesRA = useMemo(() => {
    if (!selectedBook || !selectedChapter) return [];
    return ra.verses.filter(
      v => v.book_name === selectedBook && Number(v.chapter) === Number(selectedChapter)
    );
  }, [selectedBook, selectedChapter]);

  const versesCompared = useMemo(() => (
    versesRA.map(verseRA => {
      const verseRC = rc.verses.find(
        v => v.book_name === verseRA.book_name &&
             Number(v.chapter) === Number(verseRA.chapter) &&
             Number(v.verse)   === Number(verseRA.verse)
      );
      return { verse: Number(verseRA.verse), ra: verseRA.text, rc: verseRC?.text || "" };
    })
  ), [versesRA]);

  const localVerses = useMemo(() => {
    if (selectedVersion === "ARC")
      return versesCompared.map(v => ({ verse: v.verse, text: v.rc }));
    return versesCompared.map(v => ({ verse: v.verse, text: v.ra }));
  }, [versesCompared, selectedVersion]);

  const isApiVersion   = ["NVI", "NVT"].includes(selectedVersion);
  const apiCacheKey    = `${selectedVersion}-${selectedBook}-${selectedChapter}`;
  const currentVerses  = isApiVersion ? (apiVersesCache[apiCacheKey] ?? []) : localVerses;
  const isAiParaphrase = aiParaphraseKeys.has(apiCacheKey);

  useEffect(() => {
    if (!selectedBook || !selectedChapter) return;
    const isApi = ["NVI", "NVT"].includes(selectedVersion);
    if (!isApi) return;
    const cacheKey = `${selectedVersion}-${selectedBook}-${selectedChapter}`;
    if (apiVersesCache[cacheKey]) return;
    setApiLoading(true);
    setApiError(null);

    const araVerses = ra.verses
      .filter(v => v.book_name === selectedBook && Number(v.chapter) === Number(selectedChapter))
      .map(v => ({ verse: Number(v.verse), text: v.text }));

    fetchApiChapter(selectedVersion, selectedBook, selectedChapter)
      .then(verses => setApiVersesCache(prev => ({ ...prev, [cacheKey]: verses })))
      .catch(() =>
        gerarParafraseCapitulo({
          versosARA: araVerses,
          livro:     selectedBook,
          capitulo:  selectedChapter,
          estilo:    selectedVersion,
        })
        .then(verses => {
          setApiVersesCache(prev => ({ ...prev, [cacheKey]: verses }));
          setAiParaphraseKeys(prev => new Set([...prev, cacheKey]));
        })
        .catch(err => setApiError(err.message))
      )
      .finally(() => setApiLoading(false));
  }, [selectedVersion, selectedBook, selectedChapter, apiVersesCache, fetchApiChapter]);

  const textoCapitulo = useMemo(() => (
    currentVerses.map(v => `${v.verse}. ${v.text}`).join(" ")
  ), [currentVerses]);

  const verseOfDay = useMemo(() => {
    const index = (new Date().getDate() * 37) % ra.verses.length;
    return ra.verses[index];
  }, []);

  const studyBookVerses = useMemo(() => (
    ra.verses.filter(v => v.book_name === studyBook)
  ), [studyBook]);

  // ── Navegação ────────────────────────────────────────────────────
  function goToBibleHome()    { setSelectedBook(null); setSelectedChapter(null); setActiveTab("bible"); }
  function openBook(bookName) { setSelectedBook(bookName); setSelectedChapter(null); setActiveTab("bible"); }
  function openChapter(bookName, chapter) { setSelectedBook(bookName); setSelectedChapter(Number(chapter)); setActiveTab("bible"); }
  function continueStudy()    { openChapter(studyBook, lastStudyChapter); }

  function previousChapter() {
    const idx = chapters.indexOf(Number(selectedChapter));
    if (idx > 0) setSelectedChapter(chapters[idx - 1]);
  }
  function nextChapter() {
    const idx = chapters.indexOf(Number(selectedChapter));
    if (idx >= 0 && idx < chapters.length - 1) setSelectedChapter(chapters[idx + 1]);
  }

  async function toggleOriginal(book, chapter, verse) {
    const key = `${book}-${chapter}-${verse}`;
    if (openOriginal[key]) { setOpenOriginal(p => ({ ...p, [key]: false })); return; }
    if (originalText[key]) { setOpenOriginal(p => ({ ...p, [key]: true })); return; }
    try {
      setLoadingOriginal(p => ({ ...p, [key]: true }));
      const res  = await fetch(`https://bible-api.com/${encodeURIComponent(`${book} ${chapter}:${verse}`)}`);
      const data = await res.json();
      setOriginalText(p  => ({ ...p, [key]: data?.text?.trim() || "Não foi possível carregar." }));
      setOpenOriginal(p  => ({ ...p, [key]: true }));
    } catch {
      setOriginalText(p  => ({ ...p, [key]: "Erro ao carregar o texto online." }));
      setOpenOriginal(p  => ({ ...p, [key]: true }));
    } finally {
      setLoadingOriginal(p => ({ ...p, [key]: false }));
    }
  }

  function handleOnboardingComplete() {
    localStorage.setItem(ONBOARDING_KEY, "1");
    setOnboardingDone(true);
  }

  // ════════════════════════════════════════════════════════════════
  // RENDER FUNCTIONS
  // ════════════════════════════════════════════════════════════════

  // ── Home ─────────────────────────────────────────────────────────
  function renderHome() {
    const nome = user?.displayName || localStorage.getItem("fa_nome") || "";
    return (
      <div className="screen">
        <div className="screen-header">
          {nome && <p className="screen-greeting">Olá, {nome.split(" ")[0]}! 👋</p>}
          <h2 className="screen-title">Início</h2>
          <p className="screen-sub">Leitura diária e continuidade da caminhada.</p>
        </div>

        <div className="card card--verse">
          <div className="card__eyebrow card__eyebrow--accent">✦ Versículo do dia</div>
          <div className="card__reference">{verseOfDay.book_name} {verseOfDay.chapter}:{verseOfDay.verse}</div>
          <p className="card__verse-text">{verseOfDay.text}</p>
        </div>

        <DevocionalCard studyBook={studyBook} bookVerses={studyBookVerses} />

        <div className="card card--study">
          <div className="card__eyebrow card__eyebrow--green"><BookOpen size={11} strokeWidth={2.5} /> Estudo Família Azevedo</div>
          <div className="card__meta-row">
            <span className="card__meta-item">
              <span className="card__meta-label">Livro</span>
              <span className="card__meta-value">{studyBook}</span>
            </span>
            <span className="card__meta-sep" />
            <span className="card__meta-item">
              <span className="card__meta-label">Capítulo</span>
              <span className="card__meta-value">{lastStudyChapter}</span>
            </span>
          </div>
          <button className="btn btn--primary" onClick={continueStudy}>Continuar estudo <ArrowRight size={16} strokeWidth={2} /></button>
        </div>
      </div>
    );
  }

  // ── Bible ────────────────────────────────────────────────────────
  function renderBible() {
    if (!selectedBook) {
      const visibleBooks = books.filter(b => bibleTab === "nt" ? NT_BOOKS.has(b) : !NT_BOOKS.has(b));
      return (
        <div className="screen">
          <div className="screen-header">
            <h2 className="screen-title">Bíblia</h2>
          </div>

          <div className="bible-testament-tabs">
            <button
              className={`bible-testament-tab${bibleTab === "vt" ? " bible-testament-tab--active" : ""}`}
              onClick={() => setBibleTab("vt")}
            >
              Velho Testamento
            </button>
            <button
              className={`bible-testament-tab${bibleTab === "nt" ? " bible-testament-tab--active" : ""}`}
              onClick={() => setBibleTab("nt")}
            >
              Novo Testamento
            </button>
          </div>

          <div className="book-grid">
            {visibleBooks.map(book => (
              <button key={book} className="book-grid-item" onClick={() => openBook(book)}>
                {book}
              </button>
            ))}
          </div>
        </div>
      );
    }

    if (!selectedChapter) return (
      <div className="screen">
        <button className="back-btn" onClick={goToBibleHome}><ChevronLeft size={15} strokeWidth={2.5} /> Voltar</button>
        <div className="screen-header">
          <h2 className="screen-title">{selectedBook}</h2>
          <p className="screen-sub">Selecione um capítulo.</p>
        </div>
        <div className="chapter-grid">
          {chapters.map(chapter => (
            <button key={chapter} className="chapter-btn" onClick={() => setSelectedChapter(chapter)}>
              {chapter}
            </button>
          ))}
        </div>
      </div>
    );

    const currentIndex = chapters.indexOf(Number(selectedChapter));
    const isFirst = currentIndex <= 0;
    const isLast  = currentIndex === chapters.length - 1;

    return (
      <div
        className="screen reading-screen"
        style={{
          '--verse-font-size': `${FONT_SIZES[fontSize]}px`,
          '--verse-line-height': FONT_LINES[fontSize],
        }}
      >
        <button className="back-btn" onClick={() => setSelectedChapter(null)}><ChevronLeft size={15} strokeWidth={2.5} /> Voltar</button>

        <div className="chapter-nav">
          <button className="nav-arrow" onClick={previousChapter} disabled={isFirst} aria-label="Capítulo anterior"><ChevronLeft size={20} strokeWidth={2} /></button>
          <h2 className="chapter-nav__title">{selectedBook} <span className="chapter-nav__num">{selectedChapter}</span></h2>
          <button className="nav-arrow" onClick={nextChapter} disabled={isLast} aria-label="Próximo capítulo"><ChevronRight size={20} strokeWidth={2} /></button>
        </div>

        {/* Barra de áudio */}
        <div className="audio-bar">
          {!speech.isPlaying ? (
            <button
              className="audio-bar__play-all"
              onClick={() => speech.playChapter(currentVerses)}
              title="Ler capítulo inteiro"
            >
              <span className="audio-bar__icon"><Play size={16} strokeWidth={2} /></span>
              <span>Ouvir capítulo</span>
            </button>
          ) : (
            <>
              <div className="audio-bar__playing">
                <span className="audio-bar__pulse" />
                <span className="audio-bar__label">
                  {speech.isPaused ? 'Pausado' : `Versículo ${speech.activeVerse ?? '…'}`}
                </span>
              </div>
              {speech.isPaused ? (
                <button className="audio-bar__btn" onClick={speech.resume} title="Continuar"><Play size={15} strokeWidth={2} /></button>
              ) : (
                <button className="audio-bar__btn" onClick={speech.pause} title="Pausar"><Pause size={15} strokeWidth={2} /></button>
              )}
              <button className="audio-bar__btn audio-bar__btn--stop" onClick={speech.stop} title="Parar"><Square size={14} strokeWidth={2} /></button>
            </>
          )}
        </div>

        <ChapterInsights
          livro={selectedBook}
          capitulo={selectedChapter}
          texto={textoCapitulo}
        />

        <div className="font-size-control" role="group" aria-label="Tamanho do texto">
          <span className="font-size-control__label">Texto</span>
          <div className="font-size-control__btns">
            {[
              { level: 1, aria: 'Texto pequeno',  px: 15 },
              { level: 2, aria: 'Texto médio',    px: 19 },
              { level: 3, aria: 'Texto grande',   px: 25 },
            ].map(({ level, aria, px }) => (
              <button
                key={level}
                className={`font-size-btn${fontSize === level ? ' font-size-btn--active' : ''}`}
                onClick={() => setFontSize(level)}
                aria-label={aria}
                aria-pressed={fontSize === level}
              >
                <span style={{ fontSize: px, lineHeight: 1 }}>A</span>
              </button>
            ))}
          </div>
        </div>

        <div className="version-selector">
          {VERSIONS.map(v => (
            <button
              key={v.id}
              className={`version-tab${selectedVersion === v.id ? " version-tab--active" : ""}`}
              onClick={() => { setSelectedVersion(v.id); setApiError(null); }}
            >
              {v.label}
            </button>
          ))}
        </div>

        {apiLoading && (
          <div className="version-loading">
            <div className="canela-loading" style={{ background: "transparent" }}><span /><span /><span /></div>
            <p>{isApiVersion ? `Gerando paráfrase ${selectedVersion}…` : `Carregando ${selectedVersion}…`}</p>
          </div>
        )}
        {apiError && !apiLoading && (
          <div className="version-error"><p><AlertTriangle size={14} strokeWidth={2} style={{display:'inline',verticalAlign:'middle',marginRight:4}}/>{apiError}</p></div>
        )}

        {!apiLoading && !apiError && isAiParaphrase && (
          <div className="paraphrase-notice">
            <span className="paraphrase-notice__icon">✦</span>
            <span className="paraphrase-notice__text">
              Paráfrase no estilo <strong>{selectedVersion}</strong> gerada por IA · tradução oficial em breve
            </span>
          </div>
        )}

        {!apiLoading && !apiError && (
          <div className="verses-wrap">
            {currentVerses.map(v => {
              const key       = `${selectedBook}-${selectedChapter}-${v.verse}`;
              const isReading = speech.activeVerse === v.verse;
              return (
                <div
                  key={key}
                  id={`verse-${v.verse}`}
                  className={`verse-block${isReading ? ' verse-block--reading' : ''}`}
                >
                  <div className="verse-block__number">
                    <span>{v.verse}</span>
                  </div>
                  <div className="verse-block__body">
                    <VerseText
                      text={v.text}
                      livro={selectedBook}
                      capitulo={selectedChapter}
                      versiculo={v.verse}
                    />
                    {!isApiVersion && (
                      <>
                        <button className="btn btn--ghost btn--sm" onClick={() => toggleOriginal(selectedBook, selectedChapter, v.verse)}>
                          {loadingOriginal[key] ? <><Loader2 size={12} strokeWidth={2} style={{animation:'spin 1s linear infinite'}}/> Carregando...</> : openOriginal[key] ? <><ChevronUp size={12} strokeWidth={2.5}/> Ocultar KJV</> : <><Globe size={12} strokeWidth={2}/> Ver KJV</>}
                        </button>
                        {openOriginal[key] && !loadingOriginal[key] && (
                          <div className="original-block">
                            <span className="version-badge version-badge--kjv">KJV</span>
                            <p className="original-text">{originalText[key]}</p>
                          </div>
                        )}
                      </>
                    )}
                  </div>
                  <button
                    className={`verse-play-pill${isReading ? ' verse-play-pill--active' : ''}`}
                    onClick={() => isReading ? speech.stop() : speech.playVerse(v.text, v.verse)}
                    title={isReading ? 'Parar' : 'Ouvir versículo'}
                    aria-label={isReading ? 'Parar leitura' : `Ouvir versículo ${v.verse}`}
                  >
                    <span className="verse-play-pill__icon">{isReading ? <Square size={14} strokeWidth={2} /> : <Play size={14} strokeWidth={2} />}</span>
                  </button>
                </div>
              );
            })}
          </div>
        )}

        <div className="reading-extras">
          <Anotacoes livro={selectedBook} capitulo={selectedChapter} />
        </div>

        {/* Sugestão do próximo capítulo */}
        {(() => {
          const readKeys  = new Set(readChapters.filter(k => k.startsWith(selectedBook + "||")).map(k => k.split("||")[1]));
          const next      = chapters.find(c => !readKeys.has(String(c)) && c !== Number(selectedChapter));
          if (!next) return null;
          return (
            <div className="next-chapter-card">
              <span className="next-chapter__label">Próximo não lido</span>
              <span className="next-chapter__ref">{selectedBook} {next}</span>
              <button className="btn btn--primary btn--sm" onClick={() => openChapter(selectedBook, next)}>
                Ir <ArrowRight size={14} strokeWidth={2} />
              </button>
            </div>
          );
        })()}

        <CanelaDeFogo livro={selectedBook} capitulo={selectedChapter} textoCapitulo={textoCapitulo} />
      </div>
    );
  }

  // ── Família ──────────────────────────────────────────────────────
  function renderFamilia() {
    return (
      <FamiliaTab
        uid={uid}
        user={user}
        familyId={familyId}
        familyDoc={familyDoc}
        members={allMembers}
        studyBook={studyBook}
        setStudyBook={setStudyBook}
        lastStudyChapter={lastStudyChapter}
        chaptersByBook={chaptersByBook}
        continueStudy={continueStudy}
        openBook={openBook}
        books={books}
        onCreateFamily={createFamily}
        onJoinFamily={joinFamily}
        onLeaveFamily={leaveFamily}
        onLogin={async () => {
          try { await signInWithRedirect(auth, googleProvider); }
          catch (err) { console.error(err); }
        }}
      />
    );
  }

  // ── Você ─────────────────────────────────────────────────────────
  function renderYou() {
    const localName = localStorage.getItem("fa_nome") || "Você";
    const ownMember = allMembers.find(m => m.id === uid) || {
      id: "local", name: localName,
      photoURL: null, color: AVATAR_COLORS[0],
    };

    return (
      <div className="screen">
        {/* Hero Perfil */}
        <div className="you-hero-card">
          <div className="you-hero-glow" />
          <div className="you-hero-body">
            <div className="you-avatar-ring">
              <MemberAvatar member={{ ...ownMember, photoURL: null }} size={76} isActive />
            </div>
            <div className="you-hero-info">
              <p className="you-name">{ownMember.name}</p>
              <p className="you-email">Família Azevedo</p>
              {user && <span className="you-logged-in-badge"><Cloud size={10} strokeWidth={2.5}/> Sincronizado</span>}
            </div>
          </div>
        </div>

        {/* Livro de estudo */}
        <div className="card card--study">
          <div className="card__eyebrow card__eyebrow--accent"><BookOpen size={11} strokeWidth={2.5} /> Estudo atual</div>
          <div className="you-study-row">
            <span className="you-study-name">{studyBook}</span>
            <span className="you-progress-label">cap. {lastStudyChapter} / {chaptersByBook[studyBook] || 1}</span>
          </div>
          <div className="you-progress-wrap">
            <div className="you-progress-bar">
              <div
                className="you-progress-bar__fill"
                style={{ width: `${Math.min(100, Math.round((lastStudyChapter / (chaptersByBook[studyBook] || 1)) * 100))}%` }}
              />
            </div>
          </div>
          <button className="btn btn--primary btn--full" onClick={continueStudy}>
            Continuar cap. {lastStudyChapter} <ArrowRight size={16} strokeWidth={2} />
          </button>
        </div>

        <ReadingPlan
          studyBook={studyBook}
          readChapters={readChapters}
          chaptersByBook={chaptersByBook}
        />

        {/* Configurações */}
        <div className="card">
          <div className="card__eyebrow"><Settings size={11} strokeWidth={2.5} /> Configurações</div>
          <button className="you-setting-row" onClick={() => setTheme(t => t === "light" ? "dark" : "light")}>
            <span className="you-setting-icon you-setting-icon--theme">
              {theme === "dark" ? <Moon size={17} strokeWidth={2} /> : <Sun size={17} strokeWidth={2} />}
            </span>
            <div className="you-setting-info">
              <span className="you-setting-label">Tema</span>
              <span className="you-setting-value">{theme === "dark" ? "Escuro" : "Claro"}</span>
            </div>
            <div className={`you-toggle${theme === "dark" ? " you-toggle--on" : ""}`}>
              <div className="you-toggle__thumb" />
            </div>
          </button>
          <div className="you-setting-row you-setting-row--static">
            <span className="you-setting-icon you-setting-icon--cloud">
              <Cloud size={17} strokeWidth={2} />
            </span>
            <div className="you-setting-info">
              <span className="you-setting-label">Anotações</span>
              <span className="you-setting-value">{user ? "Salvas na nuvem" : "Salvas localmente"}</span>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // ════════════════════════════════════════════════════════════════
  // ROOT RENDER
  // ════════════════════════════════════════════════════════════════

  if (!authReady) return (
    <div className="app-loading">
      <span className="app-loading-icon">✝</span>
      <span className="app-loading-text">Família Azevedo</span>
    </div>
  );

  if (!onboardingDone) return (
    <Onboarding onComplete={handleOnboardingComplete} />
  );

  return (
    <div className={`app ${theme}`}>
      <header className="topbar">
        <div className="topbar__brand">
          <div className="topbar__logo-wrap"><span className="topbar__logo">✝</span></div>
          <h1 className="topbar__title">Família Azevedo</h1>
        </div>
        <button
          className="theme-btn"
          onClick={() => setTheme(p => p === "light" ? "dark" : "light")}
          aria-label="Alternar tema"
        >
          {theme === "light" ? <Moon size={17} strokeWidth={2} /> : <Sun size={17} strokeWidth={2} />}
        </button>
      </header>

      <main className="content">
        {activeTab === "home"    && renderHome()}
        {activeTab === "bible"   && renderBible()}
        {activeTab === "familia" && renderFamilia()}
        {activeTab === "you"     && renderYou()}
      </main>

      <nav className="bottom-nav">
        {TABS.map(tab => (
          <button
            key={tab.id}
            className={`tab${activeTab === tab.id ? " tab--active" : ""}`}
            onClick={() => setActiveTab(tab.id)}
          >
            <span className="tab__emoji"><tab.Icon size={22} strokeWidth={activeTab === tab.id ? 2.2 : 1.7} /></span>
            <span className="tab__label">{tab.label}</span>
          </button>
        ))}
      </nav>
    </div>
  );
}
